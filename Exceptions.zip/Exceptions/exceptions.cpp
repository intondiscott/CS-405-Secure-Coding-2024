// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
/*
  This struct is derived from std::exception where *what() is overridden to return custom exception 
*/
struct customException:std::exception{
      const char *what() const noexcept override{
        return "My Custom Exception";
      }
  } ;

bool do_even_more_custom_application_logic()
{
  // TODO: Throw any standard exception
  throw std::range_error("An error occurred in a internal range computation...");
  std::cout << "Running Even More Custom Application Logic." << std::endl;

  return true;
}
void do_custom_application_logic()
{
  // TODO: Wrap the call to do_even_more_custom_application_logic()
  //  with an exception handler that catches std::exception, displays
  //  a message and the exception.what(), then continues processing
  try{
  std::cout << "Running Custom Application Logic." << std::endl;

  if(do_even_more_custom_application_logic())
  {
    std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
  }
  }catch(std::exception &e) 
  {
    std::cout << "An exception has been caught --> " << e.what() << std::endl;
    }
  // TODO: Throw a custom exception derived from std::exception
  //  and catch it explicitly in main
  //my custom exception thrown
  throw customException();
  
  std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{
  // TODO: Throw an exception to deal with divide by zero errors using
  //  a standard C++ defined exception
  //if den is 0 which is false in condition throw an invalid argument 
  if(!den) throw std::invalid_argument("cannot divide by 0");
  //if den is something other than 0  
  return (num / den);
  
}

void do_division() noexcept
{
  //  TODO: create an exception handler to capture ONLY the exception thrown
  //  by divide.

  float numerator = 10.0f;
  float denominator = 0;
  //wrap call and catch errors if any
  try{
  auto result = divide(numerator, denominator);
  std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
  }
  catch(std::invalid_argument &e)
  {
    std::cout << e.what() << std::endl;
  }

}

int main()
{
  std::cout << "Exceptions Tests!" << std::endl;

  // TODO: Create exception handlers that catch (in this order):
  //  your custom exception
  //  std::exception
  //  uncaught exception
  //  that wraps the whole main function, and displays a message to the console.
  try{
  do_division();
  do_custom_application_logic();
  }
  //my custom caught exception
  catch(customException &e){
    std::cout << e.what() << std::endl;
  }
  //a stardard caught exception
  catch(std::exception &e){
    std::cout << e.what() << std::endl;
  }
  // a just in case I missed any exceptions catch
  catch(...){
    std::cout << "An unexpected error has been caught!" << std::endl;
  }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
