// Uncomment the next line to use precompiled headers
//#include "pch.h"
// uncomment the next line if you do not use precompiled headers
#include "gtest/gtest.h"
#include <limits.h>
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
  ~Environment() override {}

  // Override this to define how to set up the environment.
  void SetUp() override
  {
    //  initialize random seed
    srand(time(nullptr));
  }

  // Override this to define how to tear down the environment.
  void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
  // create a smart point to hold our collection
  std::unique_ptr<std::vector<int>> collection;

  void SetUp() override
  { // create a new collection to be used in the test
    collection.reset( new std::vector<int>);
  }

  void TearDown() override
  { //  erase all elements in the collection, if any remain
    collection->clear();
    // free the pointer
    collection.reset(nullptr);
  }

  // helper function to add random values from 0 to 99 count times to the collection
  void add_entries(int count)
  {
    assert(count > 0);
    for (auto i = 0; i < count; ++i)
      collection->push_back(rand() % 100);
  }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
  // is the collection created
  ASSERT_TRUE(collection);

  // if empty, the size must be 0
  ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
  // is the collection empty?
  ASSERT_TRUE(collection->empty());

  // if empty, the size must be 0
  ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer 
TEST_F(CollectionTest, AlwaysFail)
{
  FAIL();
}*/

// TODO: Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
  // is the collection empty?
  EXPECT_TRUE(collection->empty());
  // if empty, the size must be 0
  EXPECT_EQ(collection->size(),0);
  // add 1 to collection
  add_entries(1);

  // is the collection still empty?
  ASSERT_FALSE(collection->empty());
  // if not empty, what must the size be? --> in this case 1
  ASSERT_EQ(collection->size(),1);
}

// TODO: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    //is the collection empty?
    EXPECT_TRUE(collection->empty());
    // the collection should be 0
    EXPECT_EQ(collection->size(), 0);
  add_entries(5);
  //is the collection still 0?
  ASSERT_FALSE(collection->empty());
  // are there 5 collections?
  ASSERT_EQ(collection->size(), 5);

}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest,MaxSizeGreaterThanSize){
    //is the collection empty?
    EXPECT_TRUE(collection->empty());
    //the collection should be 0
    EXPECT_EQ(collection->size(),0);
    //pass number of collections to add to collections
    
    for(int i = 0; i < 11;i++){
        
        switch (i)
        // check if MaxSize is greater than or equal to 0, 1, 5, 10
        {
        case 0:
            ASSERT_EQ(collection->size(),i);
            ASSERT_GE(collection->max_size(),i);
            break;
        case 1:
            add_entries(i);
            ASSERT_EQ(collection->size(),i);
            ASSERT_GE(collection->max_size(),i);
            break;
        case 5:
            add_entries(i-1);
            ASSERT_EQ(collection->size(),i);
            ASSERT_GE(collection->max_size(),i);
            break;
        case 10:
            add_entries(i-5);
            ASSERT_EQ(collection->size(),i);
            ASSERT_GE(collection->max_size(),i);
            break;
        default:
            break;
        }
    }
}
// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest,CapacityGreaterThanSize){
    //is the collection empty?
    EXPECT_TRUE(collection->empty());
    //the collection should be 0
    EXPECT_EQ(collection->size(),0);
    //pass number of collections to add to collections
    
    for(int i = 0; i < 11;i++){
        
        switch (i)
        // check if capacity is greater than or equal to 0, 1, 5, 10
        {
        case 0:
            ASSERT_EQ(collection->size(),i);
            ASSERT_GE(collection->capacity(),i);
            break;
        case 1:
            add_entries(i);
            ASSERT_EQ(collection->size(),i);
            ASSERT_GE(collection->capacity(),i);
            break;
        case 5:
            add_entries(i-1);
            ASSERT_EQ(collection->size(),i);
            ASSERT_GE(collection->capacity(),i);
            break;
        case 10:
            add_entries(i-5);
            ASSERT_EQ(collection->size(),i);
            ASSERT_GE(collection->capacity(),i);
            break;
        default:
            break;
        }
    }
}
// TODO: Create a test to verify resizing increases the collection
TEST_F(CollectionTest,canIncreaseSize){
    //is the collection empty?
    EXPECT_TRUE(collection->empty());
    //the collection should be 0
    EXPECT_EQ(collection->size(),0);
    // resize the collection
    collection->resize(5);
    // is the collection now 5?
    ASSERT_TRUE(collection->size() == 5);
}
// TODO: Create a test to verify resizing decreases the collection
TEST_F(CollectionTest,canDecreaseSize){
    int collectionSize = 10;
    //is the collection empty?
    EXPECT_TRUE(collection->empty());
    //the collection should be 0
    EXPECT_EQ(collection->size(),0);

    //add to collection
    add_entries(collectionSize);
    //are there 10 entries?
    ASSERT_TRUE(collection->size() == 10);
    // resize the collection
    collection->resize(--collectionSize);
    // is the collection now 9?
    ASSERT_TRUE(collection->size() == 9);
}
// TODO: Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest,canDecreaseSizeToZero){
    int collectionSize = 10;
    //is the collection empty?
    EXPECT_TRUE(collection->empty());
    //the collection should be 0
    EXPECT_EQ(collection->size(),0);

    //add to collection
    add_entries(collectionSize);
    //are there 10 entries?
    ASSERT_TRUE(collection->size() == 10);
    // resize the collection
    collection->resize(0);
    // is the collection now 0?
    ASSERT_TRUE(collection->empty());
}
// TODO: Create a test to verify clear erases the collection
TEST_F(CollectionTest,clearCollection){
    int collectionSize = 10;
    //is the collection empty?
    EXPECT_TRUE(collection->empty());
    //the collection should be 0
    EXPECT_EQ(collection->size(),0);

    //add to collection
    add_entries(10);
    //are there 10 entries?
    ASSERT_TRUE(collection->size() == 10);
    // clear the collection
    collection->clear();
    // is the collection now 0?
    ASSERT_TRUE(collection->empty());
    //the collection should be 0
    ASSERT_EQ(collection->size(),0);
}
// TODO: Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest,eraseCollection){
    int collectionSize = 10;
    //is the collection empty?
    EXPECT_TRUE(collection->empty());
    //the collection should be 0
    EXPECT_EQ(collection->size(),0);

    //add to collection
    add_entries(collectionSize);
    //are there 10 entries?
    ASSERT_TRUE(collection->size() == 10);
    // erase the collection
    collection->erase(collection->begin(),collection->end());
    // is the collection now 0?
    ASSERT_TRUE(collection->empty());
    //the collection should be 0
    ASSERT_EQ(collection->size(),0);
}
// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest,increaseReserveCollection){
    int reserveSize = 10;
    //is the collection empty?
    EXPECT_TRUE(collection->empty());
    //the collection should be 0
    EXPECT_EQ(collection->size(),0);

    //add to reserve
    collection->reserve(reserveSize);
    //are there any entries?
    ASSERT_FALSE(!collection->empty());
    // is the collection still 0?
    ASSERT_TRUE(collection->empty());
    //the collection should be 0
    ASSERT_EQ(collection->size(),0);
    //test if reserve increased
    ASSERT_TRUE(collection->capacity() == reserveSize);

}
// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
//accessing a collection outside of range should throw error
TEST_F(CollectionTest,CollectionTest_negOut_Test){
    ASSERT_THROW(collection->at(1), std::out_of_range);

}
// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative
// test if value at index 3 is 32
TEST_F(CollectionTest,addValToCollectionAtIndex){
    int val = 32;
    int index = 3;
    //is the collection empty?
    EXPECT_TRUE(collection->empty());
    //the collection should be 0
    EXPECT_EQ(collection->size(),0);
    //populate collection
    collection->assign({1,2,3,4});
    //insert new val at index
    collection->at(index) = val;
    //test if val at index is 32
    ASSERT_EQ(collection->at(index),val);

}
//accessing value in empty collection should throw out of range assertion
TEST_F(CollectionTest,accessEmptyCollection){
    //is the collection empty?
    EXPECT_TRUE(collection->empty());
    //the collection should be 0
    EXPECT_EQ(collection->size(),0);
    
   ASSERT_THROW(collection->at(0),std::out_of_range);
}
int main(int argc, char *argv[]){
    testing::InitGoogleTest(&argc, argv);
    return RUN_ALL_TESTS();
}